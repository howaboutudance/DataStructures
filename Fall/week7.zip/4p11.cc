#ifndef Btree_H
#define Btree_H

#include <iostream>
#include <set>

using namespace std;

template <typename Object>

class Btree{
	public:
		Btree(){
			root = 
		}

		~Btree(){
		}

		bool add(){
			node *temp = 
		}
	private:
		node *root;

		struct node{
  			Object data;
  			struct node *left;
  			struct node *right;
		};
};
#endif
