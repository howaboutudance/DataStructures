I felt like I was going crazt working on Q1. I focused on homework and just took a break from that.
I updated Q2 and Q3 : D
I didn't do 4 again since it was extra credit but I understand what I said was incorrect and have learned more about the queue that runs around (circular array).
