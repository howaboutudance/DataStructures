## LAB 3" ##

### Data Structures ###

### Michelle Bergin ###

I did 4.31 in my Binary Search Tree already. I had trouble only with full nodes... Not sure what is going on... :/ More than likely will bother you about it after I write this paragraph

I tried to do the expression tree but i had to use your help a lot for this... :( I feel like I am failing...
