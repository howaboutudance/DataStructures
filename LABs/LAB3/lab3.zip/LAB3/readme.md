LAB3
=====

Included is most of LAB3. If you open this then that means I haven't finished adding the iterator yet. I just want to submit things to feel like I am making progress. I appreciate your patience
