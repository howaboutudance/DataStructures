LAB3
=====

Included is all of LAB3. Thank you for all your help. Next on to Lab3'
