Just run make. This was an easy one. On to the next lab!!! 
But don't get me wrong, I learned a lot! It needed to be easy so that I had room to learn about class inheritence.
