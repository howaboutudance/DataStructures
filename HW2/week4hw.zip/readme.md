Here is what I have so far for HW2... I will try to repost more later. 
